package com.example.my_login_navigation;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.*;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements  View.OnClickListener {
   private Button button;
   private EditText editTextTextEmailAddress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        button.setOnClickListener(this);



        editTextTextEmailAddress = findViewById(R.id.editTextTextEmailAddress);
        editTextTextEmailAddress.setOnClickListener(this);




    }
   // @Override
    public void onClick(View v){
            openNewActivity();
        }

        public void openNewActivity(){
            Intent intent = new Intent(this, MainActivity2.class);
            intent.putExtra("msg",editTextTextEmailAddress.getText().toString());
            intent.putExtra("msg2","Ahlam Ahmed");
            startActivity(intent);
        }

    }
