package com.example.my_login_navigation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView username,email;



        email=findViewById(R.id.email);
        String msg_email =getIntent().getStringExtra("msg");
        email.setText(msg_email);


        username=findViewById(R.id.username);
        String msg =getIntent().getStringExtra("msg2");
        username.setText(msg);

    }
}